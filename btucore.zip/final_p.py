from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QTextEdit,
                             QPushButton, QLabel, QFileDialog, QHBoxLayout)
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QVBoxLayout, QLabel, QTextEdit, QPushButton
import sys
##mainwindow_ui
class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("btu core")
        MainWindow.resize(457, 508)
        MainWindow.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 234, 247);")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gpa = QtWidgets.QPushButton(self.centralwidget)
        self.gpa.setGeometry(QtCore.QRect(30, 230, 191, 191))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.gpa.setFont(font)
        self.gpa.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.gpa.setStyleSheet("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"  \n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}")
        self.gpa.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("pixil-frame-0 (2).png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.gpa.setIcon(icon)
        self.gpa.setIconSize(QtCore.QSize(210, 210))
        self.gpa.setObjectName("gpa")
        self.profile = QtWidgets.QPushButton(self.centralwidget)
        self.profile.setGeometry(QtCore.QRect(30, 20, 191, 191))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.profile.setFont(font)
        self.profile.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.profile.setStyleSheet("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"  \n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}")
        self.profile.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("pixil-frame-0 (1).png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.profile.setIcon(icon1)
        self.profile.setIconSize(QtCore.QSize(250, 250))
        self.profile.setObjectName("profile")
        self.game = QtWidgets.QPushButton(self.centralwidget)
        self.game.setGeometry(QtCore.QRect(240, 30, 191, 191))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.game.setFont(font)
        self.game.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.game.setStyleSheet("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"  \n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"")
        self.game.setText("")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("pixil-frame-0.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.game.setIcon(icon2)
        self.game.setIconSize(QtCore.QSize(210, 210))
        self.game.setObjectName("game")
        self.avg = QtWidgets.QPushButton(self.centralwidget)
        self.avg.setGeometry(QtCore.QRect(240, 230, 191, 191))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(50)
        self.avg.setFont(font)
        self.avg.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.avg.setStyleSheet("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"  \n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}")
        self.avg.setText("")
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("AVG.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.avg.setIcon(icon3)
        self.avg.setIconSize(QtCore.QSize(210, 210))
        self.avg.setObjectName("avg")
        self.darkmode = QtWidgets.QPushButton(self.centralwidget)
        self.darkmode.setGeometry(QtCore.QRect(344, 430, 91, 23))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        self.darkmode.setFont(font)
        self.darkmode.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.darkmode.setObjectName("darkmode")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 457, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("btu core", "btu core"))
        self.darkmode.setText(_translate("btu core", "dark mode"))
##game_ui
class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(402, 351)
        Form.setStyleSheet("background-color: rgb(255, 234, 247);")
        self.pushButton = QtWidgets.QPushButton(Form)
        self.pushButton.setGeometry(QtCore.QRect(60, 100, 271, 261))
        self.pushButton.setCursor(QtGui.QCursor(QtCore.Qt.ClosedHandCursor))
        self.pushButton.setStyleSheet("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}")
        self.pushButton.setText("")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("dog.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        icon.addPixmap(QtGui.QPixmap("dogw.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
        icon.addPixmap(QtGui.QPixmap("dogw.png"), QtGui.QIcon.Active, QtGui.QIcon.On)
        self.pushButton.setIcon(icon)
        self.pushButton.setIconSize(QtCore.QSize(298, 298))
        self.pushButton.setObjectName("pushButton")
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(30, 30, 61, 41))
        font = QtGui.QFont()
        font.setFamily("Terminal")
        self.label.setFont(font)
        self.label.setText("")
        self.label.setObjectName("label")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))



#dorg
class DogWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self.button_clicked = False
        self.click_count = 0
        self.dogw = QtGui.QIcon("dog.png")
        self.dogp = QtGui.QIcon("dogw.png")

        # self.ui.pushButton.setIcon(self.dogw)
        self.ui.pushButton.clicked.connect(self.dogpat)


        # self.ui.label.setStyleSheet("color: white; font-size: 18px;")

    def dogpat(self):
        self.click_count += 1
        if self.button_clicked:
            self.ui.pushButton.setIcon(self.dogw)
            self.ui.pushButton.setCursor(QtGui.QCursor(QtCore.Qt.ClosedHandCursor))
        else:
            self.ui.pushButton.setIcon(self.dogp)
            self.ui.pushButton.setCursor(QtGui.QCursor(QtCore.Qt.OpenHandCursor))

        self.button_clicked = not self.button_clicked
        self.ui.label.setText(f"pats: {self.click_count}")

####average scorw calc
class avgcalc(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("საშუალო ქულის გამოთვლა")
        self.resize(380, 300)
        self.setStyleSheet("background-color: rgb(255, 234, 247);")

        layout = QVBoxLayout()

        label = QLabel('შეიყვანეთ ქულები (თითო ახალ ხაზზე):')
        label.setStyleSheet("color:rgb(235, 0, 113); font-size:18px")
        layout.addWidget(label)

        self.text_edit = QTextEdit()
        self.text_edit.setPlaceholderText('შეიყვანეთ ყოველი ნიშანი ახალ ხაზზე')
        self.text_edit.setStyleSheet("color:rgb(230, 0, 115); font-size:13px")
        layout.addWidget(self.text_edit)

        self.calculate_btn = QPushButton('გამოთვლა')
        self.calculate_btn.setStyleSheet("color:rgb(235, 0, 113); font-size:20px")
        layout.addWidget(self.calculate_btn)

        self.result_label = QLabel('')
        layout.addWidget(self.result_label)

        self.setLayout(layout)
        self.calculate_btn.clicked.connect(self.calculate_average)

    def calculate_average(self):
        input_text = self.text_edit.toPlainText()
        grades = []

        for line in input_text.split('\n'):
            line = line.strip()
            if line:
                try:
                    grades.append(float(line))
                except ValueError:
                    self.result_label.setText("გთხოვთ შეიყვანეთ მხოლოდ რიცხვები!")
                    return

        if grades:
            self.result_label.setStyleSheet("color:rgb(230, 0, 115); font-size:21px")
            average = sum(grades) / len(grades)
            self.result_label.setText(f"საშუალო ქულა: {average:.2f}")
        else:
            self.result_label.setText("არ არის შეყვანილი მონაცემები.")

####profile

class profile(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("My profile")
        self.resize(350, 400)
        self.setStyleSheet("background-color: rgb(255, 234, 247);color: white;")

        

        layout = QVBoxLayout()


        self.image_label = QLabel(":P")

        self.image_label.setStyleSheet("border: 2px dashed #aaa; min-height: 150px; max-width: 200px; margin: 0 auto")
        layout.addWidget(self.image_label)

        self.upload_btn = QPushButton("ფოტოს ატვირთვა")
        self.upload_btn.setStyleSheet("color:purple; font-size:18px")
        self.upload_btn.clicked.connect(self.upload_image)
        layout.addWidget(self.upload_btn)


        self.name = QTextEdit()
        self.name.setPlaceholderText("შეიყვანეთ სახელი და გვარი")
        self.name.setStyleSheet("color:rgb(230, 0, 115); font-size: 18px;")
        layout.addWidget(self.name)

        # self.pat = QLabel(self.click)

        self.save_btn = QPushButton("შენახვა")
        self.save_btn.clicked.connect(lambda: self.save_btn.setText("შენახულია ⸜(｡˃ ᵕ ˂ )⸝♡"))
        self.save_btn.setStyleSheet("color:purple; font-size:18px")
        self.save_btn.clicked.connect(self.save_profile)
        layout.addWidget(self.save_btn)
        self.setLayout(layout)
        self.image_path = None

    def upload_image(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Photo")
        if file_path:
            self.image_path = file_path
            pixmap = QPixmap(file_path).scaled(200, 200, Qt.KeepAspectRatio)
            self.image_label.setPixmap(pixmap)

    def save_profile(self):
        print("Name:", self.name.toPlainText())

        self.close()

###################GPA CALCULATOR
import sys
import os
import sqlite3
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QComboBox, QPushButton,
                             QTableWidget, QTableWidgetItem, QLineEdit,
                             QHeaderView)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QColor, QPalette
import numpy as np

class gpacalculator(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GPA calculator")
        self.setFixedSize(500, 500)
        # con = sqlite3.connect('Final_project.sqlite3')
        #
        # cur = con.cursor()
        #
        # cur.execute('''
        #
        #     SELECT საგნები, კრედიტები FROM subject_list
        # ''')

        self.db_name = "Final_project.sqlite3"
        self.subjects = self.load_subjects()


        self.theme()

        self.init_ui()

    def theme(self):
        palette = self.palette()
        palette.setColor(QPalette.Window, QColor(255, 230, 240))
        palette.setColor(QPalette.WindowText, QColor(150, 50, 100))
        palette.setColor(QPalette.Button, QColor(255, 182, 193))
        palette.setColor(QPalette.ButtonText, QColor(100, 0, 50))
        palette.setColor(QPalette.Highlight, QColor(219, 112, 147))
        self.setPalette(palette)

    def load_subjects(self):
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            cursor.execute("SELECT საგნები, კრედიტები FROM subject_list")
            return cursor.fetchall()
        except sqlite3.Error as e:
            print(f"Database error: {e}")
            return []
        finally:
            conn.close()

    def init_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout()
        main_widget.setLayout(layout)

        title = QLabel("Semester GPA Calculator")
        title.setFont(QFont('Arial', 16, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)


        subject_layout = QHBoxLayout()

        self.subject_combo = QComboBox()
        self.subject_combo.setFont(QFont('Arial', 12))
        for subject, credits in self.subjects:
            self.subject_combo.addItem(f"{subject} ({credits} credits)", userData=credits)

        self.grade_input = QLineEdit()
        self.grade_input.setPlaceholderText("შეიყვანე ქულა (0-100)")
        self.grade_input.setValidator(QtGui.QIntValidator(0, 100))
        self.grade_input.setFont(QFont('Arial', 12))

        self.add_button = QPushButton("დაამატე საგანი")
        self.add_button.setFont(QFont('Arial', 12))
        self.add_button.clicked.connect(self.add_subject)

        subject_layout.addWidget(self.subject_combo)
        subject_layout.addWidget(self.grade_input)
        subject_layout.addWidget(self.add_button)
        layout.addLayout(subject_layout)


        self.course_table = QTableWidget()
        self.course_table.setColumnCount(3)
        self.course_table.setHorizontalHeaderLabels(["საგანი", "კრედიტი", "ქულა"])
        self.course_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.course_table.setFont(QFont('Arial', 11))
        layout.addWidget(self.course_table)


        self.gpa_label = QLabel("თქვენი GPA: 0.0")
        self.gpa_label.setFont(QFont('Arial', 14, QFont.Bold))
        self.gpa_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.gpa_label)


        self.clear_button = QPushButton("გასუფთავება")
        self.clear_button.setFont(QFont('Arial', 12))
        self.clear_button.clicked.connect(self.clear_courses)
        layout.addWidget(self.clear_button)

    def add_subject(self):


        try:
            grade = int(self.grade_input.text())
        except ValueError:
            self.show_warning("")
            return

        subject_text = self.subject_combo.currentText()
        credits = self.subject_combo.currentData()




        row = self.course_table.rowCount()
        self.course_table.insertRow(row)

        self.course_table.setItem(row, 0, QTableWidgetItem(subject_text.split(' (')[0]))
        self.course_table.setItem(row, 1, QTableWidgetItem(str(credits)))
        self.course_table.setItem(row, 2, QTableWidgetItem(str(grade)))

        self.grade_input.clear()

        self.calculate_gpa()

    def calculate_gpa(self):
        total_points = 0.0
        total_credits = 0.0

        for row in range(self.course_table.rowCount()):
            try:
                credits = float(self.course_table.item(row, 1).text())
                grade = float(self.course_table.item(row, 2).text())


                gpa_points = (grade / 100) * 4.0

                total_points += gpa_points * credits
                total_credits += credits
            except (ValueError, AttributeError):
                continue

        if total_credits > 0:
            gpa = total_points / total_credits
            self.gpa_label.setText(f"თქვენი GPA: {gpa:.2f}")
        else:
            self.gpa_label.setText("თქვენი GPA: 0.0")

    def clear_courses(self):
        self.course_table.setRowCount(0)
        self.gpa_label.setText("თქვენი GPA: 0.0")


#MAIN
class MainApplication(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)


        self.dog_window = DogWindow()
        self.avg_window = avgcalc()
        self.profile_window = profile()
        self.gpa_window = gpacalculator()
        # print(self.dog_window.label.text())

        self.ui.darkmode.clicked.connect(self.toggle_dark_mode)
        self.ui.game.clicked.connect(self.showdog)
        self.ui.avg.clicked.connect(self.showavg)
        self.ui.profile.clicked.connect(self.showprofile)
        self.ui.gpa.clicked.connect(self.showgpa)

        self.dark_mode = False

    def toggle_dark_mode(self):
        if self.dark_mode:
            self.setStyleSheet("background-color: rgb(255, 234, 247); color: black;")
            self.ui.darkmode.setText("dark mode")
        else:
            self.setStyleSheet("background-color: rgb(62, 53, 61); color: white;")
            self.ui.darkmode.setText("light mode")
        self.dark_mode = not self.dark_mode

    def showdog(self):
        self.dog_window.show()


    def showavg(self):
        self.avg_window.show()
        self.avg_window.move(
            self.geometry().center() - self.avg_window.rect().center()
        )

    def showprofile(self):
        self.profile_window.show()
        self.profile_window.move(
            self.geometry().center() - self.profile_window.rect().center()
        )

    def showgpa(self):
        self.gpa_window.show()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = MainApplication()
    window.show()
    sys.exit(app.exec_())